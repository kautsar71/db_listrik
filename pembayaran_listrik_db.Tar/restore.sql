--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tarif DROP CONSTRAINT tarif_pkey;
ALTER TABLE ONLY public.tagihan DROP CONSTRAINT tagihan_pkey;
ALTER TABLE ONLY public.penggunaan DROP CONSTRAINT penggunaan_pkey;
ALTER TABLE ONLY public.pembayaran DROP CONSTRAINT pembayaran_pkey;
ALTER TABLE ONLY public.pelanggan DROP CONSTRAINT pelanggan_pkey;
ALTER TABLE ONLY public.adminn DROP CONSTRAINT adminn_pkey;
DROP TABLE public.tarif;
DROP TABLE public.tagihan;
DROP TABLE public.penggunaan;
DROP TABLE public.pembayaran;
DROP TABLE public.pelanggan;
DROP TABLE public.adminn;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: adminn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE adminn (
    id_admin integer NOT NULL,
    username character varying(30),
    passwordd character varying(30),
    nama_admin character varying(30),
    id_level character varying(10)
);


ALTER TABLE adminn OWNER TO postgres;

--
-- Name: pelanggan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pelanggan (
    id_pelanggan integer NOT NULL,
    username character varying(30),
    passwordd character varying(30),
    nomor_kwh integer,
    nama_pelanggan character varying(30),
    alamat character varying(30),
    id_tarif character varying(10)
);


ALTER TABLE pelanggan OWNER TO postgres;

--
-- Name: pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pembayaran (
    id_pembayaran integer NOT NULL,
    id_tagihan character varying(10),
    id_pelanggan character varying(10),
    tanggal_pembayaran date,
    bulan_bayar date,
    biaya_admin integer,
    total_bayar integer,
    id_admin character varying(5)
);


ALTER TABLE pembayaran OWNER TO postgres;

--
-- Name: penggunaan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE penggunaan (
    id_penggunaan integer NOT NULL,
    id_pelanggan character varying(10),
    bulan date,
    tahun date,
    meter_awal character varying(10),
    metel_ahir character varying(10)
);


ALTER TABLE penggunaan OWNER TO postgres;

--
-- Name: tagihan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tagihan (
    id_tagihan integer NOT NULL,
    id_penggunaan character varying(10),
    id_pelanggan character varying(10),
    bulan date,
    tahun date,
    jumlah_meter integer,
    status character varying(10)
);


ALTER TABLE tagihan OWNER TO postgres;

--
-- Name: tarif; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tarif (
    id_tarif integer NOT NULL,
    daya character varying(30),
    tarifperkwh character varying(10)
);


ALTER TABLE tarif OWNER TO postgres;

--
-- Data for Name: adminn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY adminn (id_admin, username, passwordd, nama_admin, id_level) FROM stdin;
\.
COPY adminn (id_admin, username, passwordd, nama_admin, id_level) FROM '$$PATH$$/2825.dat';

--
-- Data for Name: pelanggan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pelanggan (id_pelanggan, username, passwordd, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM stdin;
\.
COPY pelanggan (id_pelanggan, username, passwordd, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM '$$PATH$$/2822.dat';

--
-- Data for Name: pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM stdin;
\.
COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM '$$PATH$$/2824.dat';

--
-- Data for Name: penggunaan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, metel_ahir) FROM stdin;
\.
COPY penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, metel_ahir) FROM '$$PATH$$/2821.dat';

--
-- Data for Name: tagihan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tagihan (id_tagihan, id_penggunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM stdin;
\.
COPY tagihan (id_tagihan, id_penggunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM '$$PATH$$/2823.dat';

--
-- Data for Name: tarif; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tarif (id_tarif, daya, tarifperkwh) FROM stdin;
\.
COPY tarif (id_tarif, daya, tarifperkwh) FROM '$$PATH$$/2826.dat';

--
-- Name: adminn adminn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY adminn
    ADD CONSTRAINT adminn_pkey PRIMARY KEY (id_admin);


--
-- Name: pelanggan pelanggan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pelanggan
    ADD CONSTRAINT pelanggan_pkey PRIMARY KEY (id_pelanggan);


--
-- Name: pembayaran pembayaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_pkey PRIMARY KEY (id_pembayaran);


--
-- Name: penggunaan penggunaan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY penggunaan
    ADD CONSTRAINT penggunaan_pkey PRIMARY KEY (id_penggunaan);


--
-- Name: tagihan tagihan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan
    ADD CONSTRAINT tagihan_pkey PRIMARY KEY (id_tagihan);


--
-- Name: tarif tarif_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tarif
    ADD CONSTRAINT tarif_pkey PRIMARY KEY (id_tarif);


--
-- PostgreSQL database dump complete
--

